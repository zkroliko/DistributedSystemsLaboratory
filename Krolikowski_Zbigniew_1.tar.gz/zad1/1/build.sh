#!/bin/bash
cmake .
make clean
make
