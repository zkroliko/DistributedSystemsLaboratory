require "rubyChat/version"

module RubyChat
  # Your code goes here...
end
